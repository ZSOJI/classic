--[[Dominos Cast Localization - Italian]]

local L = LibStub('AceLocale-3.0'):NewLocale('Dominos-CastBar', 'itIT')
if not L then return end

L.Texture = 'Motivo'
L.Width = 'Larghezza'
L.Height = 'Altezza'
L.Display_time = 'Mostra tempo'
L.Padding = 'Imbottitura'
