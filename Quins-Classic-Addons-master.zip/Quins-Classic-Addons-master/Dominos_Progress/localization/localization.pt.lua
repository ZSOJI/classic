local L = LibStub('AceLocale-3.0'):NewLocale('Dominos-Progress', 'ptBR')
if not L then return end

L["AlwaysShowText"] = "Sempre Exibir Texto"
L["CompressValues"] = "Compactar Valores"
L["Font"] = "Fonte"
L["Segmented"] = "Segmentado"
L["ShowLabels"] = "Exibir Marcadores"
L["Texture"] = "Textura"
L["Width"] = "Largura"